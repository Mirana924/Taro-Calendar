for (let i = 1; i < 36; i += 1) {
    var cell = document.createElement("div");
    cell.className = "cell";
    cell.setAttribute("id", "cell"+i);
    cell.innerHTML = i;
    if (cell.innerHTML <= getmonth()){
        cell.innerHTML = "" + i;
    } else {
        cell.innerHTML = "" + i - 31;
    }
    document.getElementsByClassName("container")[0].appendChild(cell);
}


function getmonth(){
    var d = new Date();
    var n = d.getMonth();

    if (n == 0 || n == 2 || n == 4 || n == 6 || n == 7 || n == 10 || n == 11){
        var countdate = 31;
    }
    else if (n == 1){
        var countdate = 28;
    }
    else{
        var countdate = 30;
    }
    return countdate;
}

