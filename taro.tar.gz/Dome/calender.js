for (let i = 1; i < 36; i += 1) {
    var cell = document.createElement("div");
    cell.className = "cell";
    cell.setAttribute("id", "cell"+i);
    cell.innerHTML = "" + i;
    document.getElementByClassName("container").appendChild(cell);
}
